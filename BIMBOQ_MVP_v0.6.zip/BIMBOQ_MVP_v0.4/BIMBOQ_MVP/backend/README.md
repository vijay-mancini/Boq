# BIM BOQ backend v0.2

This backend now includes snapshot import, SQLite normalization, a configurable rule engine, BOQ aggregation and Excel export, plus a minimal FastAPI read API.

## Quick start (Python 3.10+)
1. `cd backend` and `python -m pip install -r requirements.txt`
2. Import CSV snapshot: `python cli.py import PATH_TO_EXPORT --db bimboq.sqlite --name "Project Name"`
3. Copy `rules/measurement_rules.json` to your working rules location (CLI default is relative to backend folder; use absolute path if needed).
4. Calculate: `python cli.py calculate --project 1 --db bimboq.sqlite --rules ../rules/measurement_rules.json`
5. Export: `python cli.py export --project 1 --db bimboq.sqlite --output BOQ.xlsx`
6. API: `uvicorn api:app --reload` (health endpoint and read endpoints).

The engine is intentionally conservative: only rules marked active/validated run. The included PCC/RCC material rules are provisional keyword rules, not quantity certification. The extractor schema may require mapping adjustments to match actual CSV header names. Geometry-based formwork is not implemented. Always reconcile to Revit schedules and measurement standards before issuing.

### v0.3 import compatibility
The importer accepts both `Elements.csv` and `ELEMENTS.csv` (and equivalent casing/name variants for Materials, Parameters, Geometry and Errors) and maps the extractor's actual column names. Geometry and extraction-error rows are now imported. The PCC/RCC starter rules select the `NonPaint` material assignment pass to avoid a simple double-count of the separate Paint pass; this is a provisional convention and must be checked on actual project models.

Run the fixture test from the project root:
`python -m unittest discover -s tests -v`

### Classification and rule templates

Run classification directly on an extractor snapshot:

```bash
python cli.py classify path/to/snapshot
```

Generate starter element-count rules:

```bash
python cli.py templates --output architectural_count_templates.json
```

These are count-oriented templates only. They do not represent validated measurement standards or deductions.

### Snapshot health diagnostics

```bash
python cli.py health path/to/snapshot --output SNAPSHOT_HEALTH.csv
```

Reports element counts, categories, material/parameter/geometry coverage, orphan IDs, duplicate element rows and warnings about absent snapshot files. It is a diagnostic report, not a completeness certification.
