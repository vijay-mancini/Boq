"""Starter measurement-rule templates. Parameter names are model-dependent; inspect exports first."""

ARCHITECTURAL_RULE_TEMPLATES = [
    {"rule_id":"wall_count","display_name":"Wall count","filters":{"category_names":["Walls"]},"measurement":"element_count","unit":"nos","group_by":["family","type","level"],"status":"active","notes":"Count of wall elements; not a construction quantity."},
    {"rule_id":"floor_count","display_name":"Floor count","filters":{"category_names":["Floors"]},"measurement":"element_count","unit":"nos","group_by":["family","type","level"],"status":"active","notes":"Count of floor elements."},
    {"rule_id":"door_count","display_name":"Door count","filters":{"category_names":["Doors"]},"measurement":"element_count","unit":"nos","group_by":["family","type","level"],"status":"active","notes":"Count of door instances."},
    {"rule_id":"window_count","display_name":"Window count","filters":{"category_names":["Windows"]},"measurement":"element_count","unit":"nos","group_by":["family","type","level"],"status":"active","notes":"Count of window instances."},
]

def write_templates(path):
    import json
    with open(path,'w',encoding='utf-8') as f:
        json.dump({"schema_version":1,"rules":ARCHITECTURAL_RULE_TEMPLATES},f,indent=2)
