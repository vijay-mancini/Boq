import argparse
from engine import import_snapshot, calculate, export_excel
from classification import classify_snapshot
from quantity_templates import write_templates
from snapshot_health import write_health_csv

def main():
 p=argparse.ArgumentParser(description='BIM BOQ rule engine'); sub=p.add_subparsers(dest='cmd',required=True)
 i=sub.add_parser('import'); i.add_argument('folder'); i.add_argument('--db',default='bimboq.sqlite'); i.add_argument('--name')
 c=sub.add_parser('calculate'); c.add_argument('--project',type=int,required=True); c.add_argument('--db',default='bimboq.sqlite'); c.add_argument('--rules',default='../rules/measurement_rules.json')
 e=sub.add_parser('export'); e.add_argument('--project',type=int,required=True); e.add_argument('--db',default='bimboq.sqlite'); e.add_argument('--output',default='BOQ.xlsx')
 cl=sub.add_parser('classify'); cl.add_argument('folder'); cl.add_argument('--output')
 t=sub.add_parser('templates'); t.add_argument('--output',default='architectural_count_templates.json')
 h=sub.add_parser('health'); h.add_argument('folder'); h.add_argument('--output',default='SNAPSHOT_HEALTH.csv')
 a=p.parse_args()
 if a.cmd=='import': print('Imported project:',import_snapshot(a.folder,a.db,a.name))
 elif a.cmd=='calculate': print('BOQ rows:',len(calculate(a.project,a.db,a.rules)))
 elif a.cmd=='export': print('Exported rows:',export_excel(a.project,a.db,a.output),'to',a.output)
 elif a.cmd=='classify': _,counts=classify_snapshot(a.folder,a.output); print('Classification counts:',counts)
 elif a.cmd=='templates': write_templates(a.output); print('Wrote templates to',a.output)
 elif a.cmd=='health': print(write_health_csv(a.folder,a.output)); print('Wrote diagnostics to',a.output)
if __name__=='__main__': main()
