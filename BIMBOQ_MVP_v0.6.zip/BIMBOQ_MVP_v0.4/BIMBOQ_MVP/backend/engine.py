import csv, json, sqlite3, math
from collections import defaultdict
from pathlib import Path

DB_SCHEMA = """
CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY, name TEXT, source_dir TEXT, imported_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS elements(project_id INTEGER, element_id TEXT, unique_id TEXT, category TEXT, name TEXT, family TEXT, type_name TEXT, level TEXT, raw_json TEXT, PRIMARY KEY(project_id,element_id));
CREATE TABLE IF NOT EXISTS materials(project_id INTEGER, element_id TEXT, material_name TEXT, area_m2 REAL, volume_m3 REAL, pass_label TEXT, raw_json TEXT);
CREATE TABLE IF NOT EXISTS parameters(project_id INTEGER, element_id TEXT, parameter_name TEXT, value TEXT, raw_json TEXT);
CREATE TABLE IF NOT EXISTS geometry(project_id INTEGER, element_id TEXT, solid_count INTEGER, volume_m3 REAL, surface_area_m2 REAL, raw_json TEXT);
CREATE TABLE IF NOT EXISTS errors(project_id INTEGER, element_id TEXT, category TEXT, error TEXT, traceback TEXT, raw_json TEXT);
CREATE TABLE IF NOT EXISTS boq(project_id INTEGER, rule_id TEXT, item TEXT, category TEXT, family TEXT, type_name TEXT, level TEXT, unit TEXT, quantity REAL, element_ids TEXT, notes TEXT);
"""

def read_csv(folder, *names):
    folder=Path(folder)
    for name in names:
        p=folder/name
        if p.exists():
            with p.open('r',encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))
    return []

def num(v):
    try:
        x=float(str(v or '0').replace(',','')); return x if math.isfinite(x) else 0.0
    except (ValueError,TypeError): return 0.0

def clean(s): return str(s or '').strip()
def pick(row,*keys):
    for k in keys:
        if k in row and clean(row[k]): return row[k]
    return ''

def import_snapshot(folder, db_path, project_name=None):
    folder=Path(folder); db=sqlite3.connect(db_path); db.executescript(DB_SCHEMA)
    project_name=project_name or folder.name
    pid=db.execute('INSERT INTO projects(name,source_dir) VALUES (?,?)',(project_name,str(folder))).lastrowid
    elements=read_csv(folder,'ELEMENTS.csv','Elements.csv')
    for r in elements:
        eid=clean(pick(r,'ElementId','element_id'))
        if not eid: continue
        db.execute('INSERT OR REPLACE INTO elements VALUES (?,?,?,?,?,?,?,?,?)',(pid,eid,clean(pick(r,'UniqueId','unique_id')),clean(pick(r,'Category')),clean(pick(r,'ElementName','Name')),clean(pick(r,'FamilyName','Family')),clean(pick(r,'TypeName','Type')),clean(pick(r,'Level')),json.dumps(r)))
    mats=read_csv(folder,'MATERIALS.csv','Materials.csv')
    for r in mats:
        eid=clean(pick(r,'ElementId')); name=clean(pick(r,'MaterialName','Material'))
        if not eid or not name: continue
        db.execute('INSERT INTO materials VALUES (?,?,?,?,?,?,?)',(pid,eid,name,num(pick(r,'MaterialArea_m2','Area_m2','Area')),num(pick(r,'MaterialVolume_m3','Volume_m3','Volume')),clean(pick(r,'AssignmentKind','PassLabel','Pass')),json.dumps(r)))
    pars=read_csv(folder,'PARAMETERS.csv','Parameters.csv')
    for r in pars:
        eid=clean(pick(r,'ElementId')); pname=clean(pick(r,'ParameterName','Name'))
        if eid and pname: db.execute('INSERT INTO parameters VALUES (?,?,?,?,?)',(pid,eid,pname,clean(pick(r,'Value','FormattedValue')),json.dumps(r)))
    geos=read_csv(folder,'GEOMETRY.csv','Geometry.csv')
    for r in geos:
        eid=clean(pick(r,'ElementId'))
        if eid: db.execute('INSERT INTO geometry VALUES (?,?,?,?,?,?)',(pid,eid,num(pick(r,'SolidCount')),num(pick(r,'SolidVolume_m3')),num(pick(r,'SolidSurfaceArea_m2')),json.dumps(r)))
    errs=read_csv(folder,'ERRORS.csv','Errors.csv')
    for r in errs:
        db.execute('INSERT INTO errors VALUES (?,?,?,?,?,?)',(pid,clean(pick(r,'ElementId')),clean(pick(r,'Category')),clean(pick(r,'Error')),clean(pick(r,'Traceback')),json.dumps(r)))
    db.commit(); db.close(); return pid,len(elements),len(mats),len(pars),len(geos),len(errs)

def load_rules(path):
    with open(path,encoding='utf-8') as f: return json.load(f).get('rules',[])

def matches(rule,el,materials):
    filters=rule.get('filters',{})
    if filters.get('category_names') and el.get('category') not in filters['category_names']: return False
    searchable=' '.join([el.get('name',''),el.get('family',''),el.get('type_name','')]).lower()
    if filters.get('name_contains') and not any(str(t).lower() in searchable for t in filters['name_contains']): return False
    if filters.get('name_excludes') and any(str(t).lower() in searchable for t in filters['name_excludes']): return False
    if filters.get('material_name_contains') and not any(any(str(t).lower() in m.get('material_name','').lower() for t in filters['material_name_contains']) for m in materials): return False
    if filters.get('level_contains') and not any(str(t).lower() in el.get('level','').lower() for t in filters['level_contains']): return False
    return True

def get_parameter_value(parameters, name):
    # Case-insensitive exact match, with optional aliases configured by rule.
    return parameters.get(str(name).lower(), '')


def calculate(project_id,db_path,rules_path):
    rules=load_rules(rules_path); db=sqlite3.connect(db_path); db.row_factory=sqlite3.Row
    els=db.execute('SELECT * FROM elements WHERE project_id=?',(project_id,)).fetchall()
    mats=db.execute('SELECT * FROM materials WHERE project_id=?',(project_id,)).fetchall(); matmap=defaultdict(list)
    for m in mats: matmap[m['element_id']].append(dict(m))
    geos={r['element_id']:dict(r) for r in db.execute('SELECT * FROM geometry WHERE project_id=?',(project_id,))}
    pmap=defaultdict(dict)
    for p in db.execute('SELECT * FROM parameters WHERE project_id=?',(project_id,)): pmap[p['element_id']][p['parameter_name'].lower()]=p['value']
    db.execute('DELETE FROM boq WHERE project_id=?',(project_id,)); aggregate={}
    for er in els:
        el=dict(er); eid=el['element_id']; el['parameters']=pmap[eid]; mm=matmap[eid]; geo=geos.get(eid,{})
        for rule in rules:
            if rule.get('status') not in ('active','validated') or not matches(rule,el,mm): continue
            meas=rule.get('measurement'); q=0.0; filt=rule.get('filters',{})
            selected=mm
            pass_filter=rule.get('material_assignment_kinds') or filt.get('material_assignment_kinds')
            if pass_filter: selected=[m for m in mm if m['pass_label'].lower() in [x.lower() for x in pass_filter]]
            mat_terms=filt.get('material_name_contains')
            if meas=='material_volume_m3': q=sum(m['volume_m3'] for m in selected if not mat_terms or any(t.lower() in m['material_name'].lower() for t in mat_terms))
            elif meas=='material_area_m2': q=sum(m['area_m2'] for m in selected if not mat_terms or any(t.lower() in m['material_name'].lower() for t in mat_terms))
            elif meas=='geometry_volume_m3': q=num(geo.get('volume_m3'))
            elif meas=='geometry_surface_area_m2': q=num(geo.get('surface_area_m2'))
            elif meas.startswith('parameter:'): q=num(get_parameter_value(pmap[eid],meas.split(':',1)[1]))
            elif meas=='element_count': q=1.0
            elif meas.startswith('parameter_area:'): q=num(get_parameter_value(pmap[eid],meas.split(':',1)[1]))
            elif meas.startswith('parameter_length:'): q=num(get_parameter_value(pmap[eid],meas.split(':',1)[1]))
            else: continue
            if q<=0: continue
            keys=rule.get('group_by',[]); key=tuple(el.get({'category':'category','family':'family','type':'type_name','level':'level'}.get(k,k),'') for k in keys)
            full=(rule['rule_id'],rule['display_name'],rule.get('unit',''),key)
            aggregate.setdefault(full,{'quantity':0.0,'ids':set(),'notes':rule.get('notes','')}); aggregate[full]['quantity']+=q; aggregate[full]['ids'].add(eid)
    for (rid,item,unit,key),v in aggregate.items():
        group_fields=rules_by_id(rules,rid).get('group_by',[]); vals=dict(zip(group_fields,key))
        db.execute('INSERT INTO boq VALUES (?,?,?,?,?,?,?,?,?,?,?)',(project_id,rid,item,vals.get('category',''),vals.get('family',''),vals.get('type',''),vals.get('level',''),unit,v['quantity'],','.join(sorted(v['ids'],key=lambda x:(len(x),x))),v['notes']))
    db.commit(); rows=[dict(r) for r in db.execute('SELECT * FROM boq WHERE project_id=?',(project_id,))]; db.close(); return rows

def rules_by_id(rules,rid): return next(r for r in rules if r['rule_id']==rid)

def export_excel(project_id,db_path,output_path):
    from openpyxl import Workbook
    from openpyxl.styles import Font,PatternFill,Alignment
    db=sqlite3.connect(db_path); db.row_factory=sqlite3.Row
    rows=db.execute('SELECT * FROM boq WHERE project_id=? ORDER BY item,category,family,type_name,level',(project_id,)).fetchall()
    wb=Workbook(); ws=wb.active; ws.title='BOQ'; headers=['Item','Category','Family','Type','Level','Unit','Quantity','Rule ID','Element IDs','Notes']; ws.append(headers)
    for r in rows: ws.append([r['item'],r['category'],r['family'],r['type_name'],r['level'],r['unit'],r['quantity'],r['rule_id'],r['element_ids'],r['notes']])
    for c in ws[1]: c.font=Font(bold=True,color='FFFFFF'); c.fill=PatternFill('solid',fgColor='244062'); c.alignment=Alignment(wrap_text=True)
    ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions
    for col in ws.columns:
        letter=col[0].column_letter; ws.column_dimensions[letter].width=min(max(max(len(str(c.value or '')) for c in col)+2,12),48)
    audit=wb.create_sheet('Audit'); audit.append(['Project ID',project_id]); audit.append(['BOQ rows',len(rows)]); audit.append(['Generated by configurable rule engine']); audit.append(['Quantity caveat','Verify rule scope, model assumptions, units and materials before use.'])
    wb.save(output_path); db.close(); return len(rows)
