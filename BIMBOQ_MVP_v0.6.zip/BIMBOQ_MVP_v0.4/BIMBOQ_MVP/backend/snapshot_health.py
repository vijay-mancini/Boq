"""Snapshot diagnostics: checks coverage and structural consistency without modifying data."""
import csv
from pathlib import Path
from collections import Counter

def _read(path):
    if not path.exists(): return []
    with path.open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))

def health_report(folder):
    folder=Path(folder)
    elements=_read(folder/'ELEMENTS.csv') or _read(folder/'Elements.csv')
    materials=_read(folder/'MATERIALS.csv') or _read(folder/'Materials.csv')
    parameters=_read(folder/'PARAMETERS.csv') or _read(folder/'Parameters.csv')
    geometry=_read(folder/'GEOMETRY.csv') or _read(folder/'Geometry.csv')
    errors=_read(folder/'ERRORS.csv') or _read(folder/'Errors.csv')
    ids={str(r.get('ElementId','')).strip() for r in elements if str(r.get('ElementId','')).strip()}
    categories=Counter(str(r.get('Category','') or 'Unknown').strip() for r in elements)
    mat_ids={str(r.get('ElementId','')).strip() for r in materials if str(r.get('ElementId','')).strip()}
    param_ids={str(r.get('ElementId','')).strip() for r in parameters if str(r.get('ElementId','')).strip()}
    geo_ids={str(r.get('ElementId','')).strip() for r in geometry if str(r.get('ElementId','')).strip()}
    missing=[]
    if not elements: missing.append('ELEMENTS.csv missing or empty')
    if not materials: missing.append('MATERIALS.csv missing or empty')
    if not parameters: missing.append('PARAMETERS.csv missing or empty')
    if not geometry: missing.append('GEOMETRY.csv missing or empty')
    if not errors: missing.append('ERRORS.csv missing or empty (cannot distinguish zero errors from unavailable log)')
    duplicates= len([r for r in elements if r.get('ElementId')]) - len(ids)
    return {
      'snapshot_folder':str(folder),'element_rows':len(elements),'unique_element_ids':len(ids),'duplicate_element_rows':duplicates,
      'category_counts':dict(categories),'material_rows':len(materials),'elements_with_materials':len(mat_ids & ids),
      'parameter_rows':len(parameters),'elements_with_parameters':len(param_ids & ids),'geometry_rows':len(geometry),
      'elements_with_geometry':len(geo_ids & ids),'error_rows':len(errors),'material_element_ids_not_in_elements':len(mat_ids-ids),
      'parameter_element_ids_not_in_elements':len(param_ids-ids),'geometry_element_ids_not_in_elements':len(geo_ids-ids),'warnings':missing
    }

def write_health_csv(folder,output):
    import json
    report=health_report(folder)
    with open(output,'w',encoding='utf-8-sig',newline='') as f:
      w=csv.writer(f);w.writerow(['Metric','Value'])
      for k,v in report.items():w.writerow([k,json.dumps(v) if isinstance(v,(dict,list)) else v])
    return report
