# Development increment v0.5

## Implemented
- Architectural element-count measurement (`element_count`) within rule engine.
- Starter JSON templates for counts of walls, floors, doors, windows.
- CLI `classify` and `templates` commands.
- Synthetic tests for classification, category-based count rules, and wrong-category rejection.

## Validation
- `python -m unittest discover -s tests -v`: 3/3 passed.
- Validation uses synthetic fixtures, not a live Revit model.

## Limitations
- Count rules are simple instance counts.
- Net/gross area, volume, length and deductions still require robust model-aware rules, units and validated parameter conventions.
- Classification is category-based and heuristic.

## v0.6 increment
- Added snapshot health diagnostics (coverage, category counts, duplicate rows, orphan IDs, missing-file warnings).
- Added CLI `health` command to generate `SNAPSHOT_HEALTH.csv`.
- Added synthetic health test.
- Combined suite: 4/4 tests pass.
