import csv,tempfile,unittest
from pathlib import Path
from backend.snapshot_health import health_report
class HealthTests(unittest.TestCase):
 def test_health_coverage_and_orphan_detection(self):
  with tempfile.TemporaryDirectory() as td:
   d=Path(td)
   def w(n,h,rows):
    with (d/n).open('w',newline='',encoding='utf-8') as f:
     x=csv.DictWriter(f,fieldnames=h);x.writeheader();x.writerows(rows)
   w('ELEMENTS.csv',['ElementId','Category'],[{'ElementId':'1','Category':'Walls'}])
   w('MATERIALS.csv',['ElementId','MaterialName'],[{'ElementId':'1','MaterialName':'Concrete'},{'ElementId':'999','MaterialName':'Orphan'}])
   w('PARAMETERS.csv',['ElementId','ParameterName'],[{'ElementId':'1','ParameterName':'Length'}])
   w('GEOMETRY.csv',['ElementId'],[{'ElementId':'1'}]);w('ERRORS.csv',['ElementId'],[])
   r=health_report(d);self.assertEqual(r['unique_element_ids'],1);self.assertEqual(r['material_element_ids_not_in_elements'],1);self.assertEqual(r['elements_with_geometry'],1)
if __name__=='__main__':unittest.main()
