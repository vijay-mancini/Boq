import csv, json, tempfile, sqlite3, unittest
from pathlib import Path
from backend.engine import import_snapshot, calculate
from backend.classification import classify_snapshot

class ArchitecturalTests(unittest.TestCase):
 def test_category_classification_and_count_rules(self):
  with tempfile.TemporaryDirectory() as td:
   d=Path(td); db=d/'db.sqlite'; rules=d/'rules.json'
   with (d/'ELEMENTS.csv').open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['ElementId','Category','ElementName','FamilyName','TypeName','Level']);w.writeheader();w.writerows([
      {'ElementId':'1','Category':'Walls','ElementName':'Wall A','FamilyName':'Basic Wall','TypeName':'200mm','Level':'L1'},
      {'ElementId':'2','Category':'Doors','ElementName':'Door A','FamilyName':'Door Family','TypeName':'900x2100','Level':'L1'},
      {'ElementId':'3','Category':'Windows','ElementName':'Window A','FamilyName':'Window Family','TypeName':'1200x1200','Level':'L2'}])
   with (d/'Parameters.csv').open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['ElementId','ParameterName','Value']);w.writeheader();w.writerow({'ElementId':'1','ParameterName':'Length','Value':'5'})
   import_snapshot(d,db,'test')
   with rules.open('w') as f: json.dump({'rules':[{'rule_id':'count_walls','display_name':'Walls','filters':{'category_names':['Walls']},'measurement':'element_count','unit':'nos','group_by':['category'],'status':'active'}]},f)
   rows=calculate(1,db,rules);self.assertEqual(len(rows),1);self.assertEqual(rows[0]['quantity'],1)
   res,counts=classify_snapshot(d);self.assertEqual(counts['Wall'],1);self.assertEqual(counts['Door'],1);self.assertEqual(counts['Window'],1)
 def test_category_filter_rejects_wrong_category(self):
  with tempfile.TemporaryDirectory() as td:
   d=Path(td);db=d/'db.sqlite';rp=d/'rules.json'
   with (d/'ELEMENTS.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=['ElementId','Category']);w.writeheader();w.writerow({'ElementId':'1','Category':'Doors'})
   import_snapshot(d,db)
   with rp.open('w') as f:json.dump({'rules':[{'rule_id':'walls','display_name':'Walls','filters':{'category_names':['Walls']},'measurement':'element_count','unit':'nos','group_by':[],'status':'active'}]},f)
   self.assertEqual(calculate(1,db,rp),[])
if __name__=='__main__':unittest.main()
