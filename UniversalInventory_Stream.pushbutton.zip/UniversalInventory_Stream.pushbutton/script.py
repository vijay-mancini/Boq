# -*- coding: utf-8 -*-
# Universal Inventory - streaming pyRevit PushButton
# Writes directly to UTF-8 CSV files to avoid retaining the whole model inventory in RAM.
# Read-only. Geometry traversal is intentionally excluded in this stability-focused build.

from pyrevit import revit, forms, script
from Autodesk.Revit.DB import FilteredElementCollector, ElementId, BuiltInParameter
import os, sys, traceback

DOC = revit.doc
OUT = script.get_output()

try:
    folder = forms.pick_folder(title='Choose folder for Universal Inventory CSV files')
    if not folder:
        script.exit()
except:
    folder = None
if not folder:
    script.exit()

# Writer uses System.IO for predictable UTF-8 output across IronPython/Python runtimes.
from System.IO import StreamWriter
from System.Text import Encoding

class CsvWriter(object):
    def __init__(self, path, headers):
        self.headers = headers
        self.writer = StreamWriter(path, False, Encoding.UTF8)
        self.write_row(headers)
    def _cell(self, value):
        if value is None: value = ''
        try: value = unicode(value)
        except:
            try: value = str(value)
            except: value = ''
        value = value.replace('"','""')
        if ',' in value or '"' in value or '\n' in value or '\r' in value:
            value = '"' + value + '"'
        return value
    def write_row(self, row):
        self.writer.WriteLine(','.join([self._cell(x) for x in row]))
    def write_dict(self, row):
        self.write_row([row.get(h,'') for h in self.headers])
    def close(self):
        try: self.writer.Flush()
        except: pass
        try: self.writer.Close()
        except: pass

master_headers = ['Document','Element ID','Unique ID','Kind','Category','Category ID','Element Name','API Class','Family','Type Name','Type ID','Level','Level ID','Description','Mark','Host ID','Host Name','Location Type','X (ft)','Y (ft)','Z (ft)','End X (ft)','End Y (ft)','End Z (ft)','BBox Width (ft)','BBox Depth (ft)','BBox Height (ft)','BBox Width (m)','BBox Depth (m)','BBox Height (m)']
param_headers = ['Document','Element ID','Kind','Category','Parameter Name','Value','Formatted Value','Storage Type','Parameter ID','Shared GUID','Read Only']
material_headers = ['Document','Element ID','Category','Material ID','Material Name','Material Class','Material Area (ft2)','Material Volume (ft3)']
audit_headers = ['Document','Element ID','Unique ID','Kind','Category','Status','Note']
error_headers = ['Document','Element ID','Stage','Error']

master = CsvWriter(os.path.join(folder,'ALL_ELEMENTS.csv'), master_headers)
params = CsvWriter(os.path.join(folder,'ALL_PARAMETERS.csv'), param_headers)
materials = CsvWriter(os.path.join(folder,'ALL_MATERIALS.csv'), material_headers)
audit = CsvWriter(os.path.join(folder,'ELEMENT_AUDIT.csv'), audit_headers)
errors = CsvWriter(os.path.join(folder,'ERRORS.csv'), error_headers)

count_inst = 0
count_types = 0
count_failed = 0


def safe(fn, default=''):
    try: return fn()
    except: return default

def idstr(eid):
    if eid is None: return ''
    try: return str(eid.Value)
    except:
        try: return str(eid.IntegerValue)
        except: return ''

def name(el):
    return safe(lambda: el.Name, safe(lambda: el.get_Name(),''))

def catname(el):
    return safe(lambda: el.Category.Name,'')

def parameter_raw(p):
    try:
        st=str(p.StorageType)
        if st == 'String': return safe(lambda:p.AsString(), safe(lambda:p.AsValueString(),''))
        if st == 'Integer': return p.AsInteger()
        if st == 'Double': return p.AsDouble()
        if st == 'ElementId': return idstr(p.AsElementId())
        return safe(lambda:p.AsValueString(),'')
    except: return ''

def type_for(el):
    try:
        tid=el.GetTypeId()
        if tid and tid != ElementId.InvalidElementId:
            return DOC.GetElement(tid)
    except: pass
    return None

def level_for(el):
    try:
        lid=el.LevelId
        if lid and lid != ElementId.InvalidElementId:
            l=DOC.GetElement(lid)
            if l: return name(l),idstr(lid)
    except: pass
    for bip in [BuiltInParameter.LEVEL_PARAM, BuiltInParameter.INSTANCE_REFERENCE_LEVEL_PARAM]:
        try:
            p=el.get_Parameter(bip)
            if p:
                lid=p.AsElementId(); l=DOC.GetElement(lid)
                if l: return name(l),idstr(lid)
        except: pass
    return '', ''

def loc_bbox(el):
    data=['','','','','','','','','']
    try:
        loc=el.Location
        if loc:
            try:
                pt=loc.Point
                data[0]='Point'; data[1]=pt.X; data[2]=pt.Y; data[3]=pt.Z
            except:
                try:
                    c=loc.Curve; a=c.GetEndPoint(0); b=c.GetEndPoint(1)
                    data[0]='Curve'; data[1]=a.X; data[2]=a.Y; data[3]=a.Z; data[4]=b.X; data[5]=b.Y; data[6]=b.Z
                except: pass
    except: pass
    dims=['','','','','','','']
    try:
        bb=el.get_BoundingBox(None)
        if bb:
            dx=abs(bb.Max.X-bb.Min.X); dy=abs(bb.Max.Y-bb.Min.Y); dz=abs(bb.Max.Z-bb.Min.Z)
            dims=[dx,dy,dz,dx*0.3048,dy*0.3048,dz*0.3048]
    except: pass
    return data,dims

def process(el, kind):
    global count_failed
    eid=idstr(el.Id); cat=catname(el); uid=safe(lambda:el.UniqueId,'')
    try:
        typ=el if kind=='TYPE' else type_for(el)
        type_name=name(typ) if typ else ''
        fam=safe(lambda:typ.FamilyName,'') if typ else ''
        if not fam and typ:
            fam=safe(lambda:typ.Family.Name,'')
        lev,lev_id=level_for(el)
        host=None
        try: host=el.Host
        except: pass
        hostid=idstr(host.Id) if host else ''; hostname=name(host) if host else ''
        ld,bd=loc_bbox(el)
        row=[DOC.Title,eid,uid,kind,cat,idstr(safe(lambda:el.Category.Id,None)),name(el),safe(lambda:el.GetType().Name,''),fam,type_name,idstr(safe(lambda:el.GetTypeId(),None)),lev,lev_id,
             safe(lambda:el.LookupParameter('Description').AsString() if el.LookupParameter('Description') else ''),safe(lambda:el.LookupParameter('Mark').AsString() if el.LookupParameter('Mark') else ''),hostid,hostname]
        row += [ld[0],ld[1],ld[2],ld[3],ld[4],ld[5],ld[6]]
        row += [bd[0],bd[1],bd[2],bd[3],bd[4],bd[5]]
        master.write_row(row)
        # Stream parameter records individually, never build a large parameter list.
        try:
            for p in el.Parameters:
                try:
                    d=p.Definition; pname=d.Name if d else ''
                    guid=safe(lambda:p.GUID.ToString(),'') if safe(lambda:p.IsShared,False) else ''
                    params.write_row([DOC.Title,eid,kind,cat,pname,parameter_raw(p),safe(lambda:p.AsValueString(),''),safe(lambda:str(p.StorageType),''),idstr(safe(lambda:p.Id,None)),guid,safe(lambda:p.IsReadOnly,'')])
                except Exception as px:
                    errors.write_row([DOC.Title,eid,'Parameter',str(px)])
        except Exception as px:
            errors.write_row([DOC.Title,eid,'Parameter collection',str(px)])
        # Materials are attempted conservatively; failures are logged, not fatal.
        try:
            for mid in el.GetMaterialIds(False):
                try:
                    m=DOC.GetElement(mid)
                    if not m: continue
                    area=safe(lambda:el.GetMaterialArea(mid,False),'')
                    vol=safe(lambda:el.GetMaterialVolume(mid),'')
                    materials.write_row([DOC.Title,eid,cat,idstr(mid),name(m),safe(lambda:m.MaterialClass,''),area,vol])
                except Exception as mx:
                    errors.write_row([DOC.Title,eid,'Material',str(mx)])
        except Exception as mx:
            errors.write_row([DOC.Title,eid,'Material collection',str(mx)])
        audit.write_row([DOC.Title,eid,uid,kind,cat,'OK',''])
    except Exception as ex:
        count_failed += 1
        errors.write_row([DOC.Title,eid,'Element processing',str(ex)])
        audit.write_row([DOC.Title,eid,uid,kind,cat,'FAILED',str(ex)])

try:
    forms.alert('Streaming extraction started. CSV files are written continuously to disk. Geometry traversal is excluded in this stability build.\n\nDo not close Revit until finished.', title='Universal Inventory', ok=True)
    # Instance collector pass
    collector=FilteredElementCollector(DOC).WhereElementIsNotElementType()
    for el in collector:
        process(el,'INSTANCE')
        count_inst += 1
    # Independently collect types
    collector2=FilteredElementCollector(DOC).WhereElementIsElementType()
    for el in collector2:
        process(el,'TYPE')
        count_types += 1
    forms.alert('Extraction finished.\nInstances: %s\nTypes: %s\nFailed: %s\n\nCSV files saved in:\n%s' % (count_inst,count_types,count_failed,folder), title='Universal Inventory Complete', ok=True)
except Exception as ex:
    errors.write_row([DOC.Title,'','Main process',str(ex)])
    forms.alert('Extraction stopped unexpectedly. Check ERRORS.csv and ELEMENT_AUDIT.csv.\n\n%s' % str(ex), title='Universal Inventory', ok=True)
finally:
    for w in [master,params,materials,audit,errors]:
        try: w.close()
        except: pass
