# -*- coding: utf-8 -*-
"""Shared data store for the BOQ workflow."""
APP_DATA = {
    'client': {'name': '', 'contact': '', 'email': ''},
    'project': {'name': '', 'number': '', 'location': ''},
    'selections': {'landscape': [], 'architecture': [], 'interior': []}
}

def reset():
    APP_DATA['client'] = {'name': '', 'contact': '', 'email': ''}
    APP_DATA['project'] = {'name': '', 'number': '', 'location': ''}
    APP_DATA['selections'] = {'landscape': [], 'architecture': [], 'interior': []}
