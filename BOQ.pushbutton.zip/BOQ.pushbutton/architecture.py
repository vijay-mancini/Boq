# -*- coding: utf-8 -*-
"""Placeholder page. Requirements will be added when specified."""
from System.Windows.Markup import XamlReader

def load_view(xaml_path):
    with open(xaml_path, "r") as handle:
        return XamlReader.Parse(handle.read())
