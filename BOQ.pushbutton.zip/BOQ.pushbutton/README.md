# Mancini BOQ Generator — pyRevit starter

Copy this folder's contents into `BOQ.tab/BOQ.panel/BOQ.pushbutton/`. The `script.py` entry point only launches `main.launch()`.

## Files
- `main.py` / `main.xaml`: persistent application shell and sidebar.
- `landing.py` / `landing.xaml`: client and project details.
- `landscape.py` / `landscape.xaml`: approved landscape selection UI and selection logic.
- `architecture.py` / `architecture.xaml`: placeholder until requirements are supplied.
- `interior.py` / `interior.xaml`: placeholder until requirements are supplied.
- `data_manager.py`: shared project and selection data.

## Run
Run the pushbutton from inside Revit using pyRevit. WPF/.NET imports such as `System.Windows` are not available in ordinary CPython.

## Notes
The landscape selection page preserves the approved category cards, search, live summary, and footer controls. Its old in-page workflow navigation was moved to the persistent application sidebar so changing modules replaces only the right-hand content. Architecture and Interior intentionally contain no assumed item fields yet.
