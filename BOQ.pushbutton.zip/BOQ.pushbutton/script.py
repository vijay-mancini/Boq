# -*- coding: utf-8 -*-
"""pyRevit pushbutton entry point. Keep this file as the launcher only."""
from main import launch
launch()
