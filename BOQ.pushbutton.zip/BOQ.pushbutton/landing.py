# -*- coding: utf-8 -*-
"""Client and project details page."""
from System.Windows.Markup import XamlReader
from data_manager import APP_DATA

def load_view(xaml_path, on_continue):
    with open(xaml_path, 'r') as handle:
        view = XamlReader.Parse(handle.read())
    def save_and_continue(sender, args):
        client = APP_DATA['client']
        project = APP_DATA['project']
        client['name'] = view.FindName('ClientName').Text.strip()
        client['contact'] = view.FindName('ClientContact').Text.strip()
        client['email'] = view.FindName('ClientEmail').Text.strip()
        project['name'] = view.FindName('ProjectName').Text.strip()
        project['number'] = view.FindName('ProjectNumber').Text.strip()
        project['location'] = view.FindName('ProjectLocation').Text.strip()
        on_continue()
    view.FindName('ContinueButton').Click += save_and_continue
    return view
