# -*- coding: utf-8 -*-
"""Main BOQ application shell. Keeps the sidebar and swaps only right content."""
import clr
clr.AddReference("PresentationFramework")
clr.AddReference("PresentationCore")
clr.AddReference("WindowsBase")
import os
from System.Windows.Markup import XamlReader
from System.Windows import Thickness
from landing import load_view as load_landing
from landscape import load_view as load_landscape
from architecture import load_view as load_architecture
from interior import load_view as load_interior

BASE_DIR = os.path.dirname(__file__)
def path(name):
    return os.path.join(BASE_DIR, name)

def launch():
    with open(path('main.xaml'), 'r') as handle:
        window = XamlReader.Parse(handle.read())
    host = window.FindName('ContentHost')

    def show_landing():
        host.Content = load_landing(path('landing.xaml'), show_landscape)
    def show_landscape():
        host.Content = load_landscape(path('landscape.xaml'), lambda items: show_landing() if items is None else None, show_landing)
    def show_architecture():
        host.Content = load_architecture(path('architecture.xaml'))
    def show_interior():
        host.Content = load_interior(path('interior.xaml'))

    window.FindName('LandingNav').Click += lambda s, e: show_landing()
    window.FindName('LandscapeNav').Click += lambda s, e: show_landscape()
    window.FindName('ArchitectureNav').Click += lambda s, e: show_architecture()
    window.FindName('InteriorNav').Click += lambda s, e: show_interior()
    show_landing()
    window.ShowDialog()
