# -*- coding: utf-8 -*-
"""Landscape item selection page for the pyRevit BOQ tool."""
from System.Windows.Markup import XamlReader
from System.Windows import Visibility
from pyrevit import forms
from data_manager import APP_DATA

CATEGORIES = {
    "Site & Hardscape": ["Paving", "Kerb", "Steps", "Ramp", "RetainingWall"],
    "Softscape": ["Lawn", "Planting", "Trees", "Hedge", "GroundCover"],
    "Site Furniture": ["Bench", "TrashBin", "Bollard", "BikeRack", "Planter"],
    "Lighting": ["PathwayLight", "PoleLight", "BollardLight", "InGroundLight"],
    "Water Features": ["Fountain", "Pond", "WaterBody", "Waterfall"],
    "Site Utilities": ["Irrigation", "Drainage", "Manhole", "UtilityEnclosure"]
}
SUMMARY_NAMES = {
    "Site & Hardscape": "HardscapeCount", "Softscape": "SoftscapeCount",
    "Site Furniture": "FurnitureCount", "Lighting": "LightingCount",
    "Water Features": "WaterCount", "Site Utilities": "UtilitiesCount"
}

def load_view(xaml_path, on_complete, on_back):
    with open(xaml_path, 'r') as handle:
        view = XamlReader.Parse(handle.read())
    names = [name for group in CATEGORIES.values() for name in group]

    def selected_items():
        result = []
        for category, item_names in CATEGORIES.items():
            for name in item_names:
                control = view.FindName(name)
                if control.IsChecked:
                    result.append({'category': category, 'item': control.Content.ToString()})
        return result

    def update_summary(sender=None, args=None):
        total = 0
        for category, item_names in CATEGORIES.items():
            count = sum(1 for name in item_names if view.FindName(name).IsChecked)
            total += count
            view.FindName(SUMMARY_NAMES[category]).Text = '{} selected'.format(count)
        view.FindName('TotalSelected').Text = '{} items selected'.format(total)

    def on_search(sender, args):
        query = view.FindName('SearchBox').Text.strip().lower()
        for name in names:
            checkbox = view.FindName(name)
            label = checkbox.Content.ToString().lower()
            checkbox.Visibility = Visibility.Visible if (not query or query in label) else Visibility.Collapsed

    def on_next(sender, args):
        items = selected_items()
        if not items:
            forms.alert('Please select at least one landscape item.', title='No items selected')
            return
        APP_DATA['selections']['landscape'] = items
        on_complete(items)

    def on_cancel(sender, args):
        on_complete(None)

    def on_back_click(sender, args):
        on_back()

    for name in names:
        view.FindName(name).Checked += update_summary
        view.FindName(name).Unchecked += update_summary
    view.FindName('SearchBox').TextChanged += on_search
    view.FindName('NextButton').Click += on_next
    view.FindName('CancelButton').Click += on_cancel
    view.FindName('BackButton').Click += on_back_click
    update_summary()
    return view
