# -*- coding: utf-8 -*-
# Universal Revit Inventory - pyRevit PushButton
# Read-only model inventory export to Excel. Revit 2024-2026 API.

from pyrevit import revit, forms, script
from Autodesk.Revit.DB import FilteredElementCollector, ElementId, BuiltInParameter, Solid, GeometryInstance, Options
import os, json, traceback
from collections import defaultdict

DOC = revit.doc
INCLUDE_TYPES = True
INCLUDE_GEOMETRY_SUMMARY = True
INCLUDE_MATERIALS = True


def safe(fn, fallback=''):
    try: return fn()
    except: return fallback


def eid(eid_obj):
    try:
        return str(eid_obj.Value) if hasattr(eid_obj, 'Value') else str(eid_obj.IntegerValue)
    except: return ''


def name(el):
    return safe(lambda: el.Name, '')


def category(el):
    return safe(lambda: el.Category.Name if el.Category else '', '')


def param_value(p):
    try:
        st = str(p.StorageType)
        if st == 'String': return p.AsString() or p.AsValueString() or ''
        if st == 'Integer': return p.AsInteger()
        if st == 'Double': return p.AsDouble()
        if st == 'ElementId': return eid(p.AsElementId())
        return p.AsValueString() or ''
    except: return safe(lambda: p.AsValueString(), '')


def get_type(el, source_doc):
    try:
        tid = el.GetTypeId()
        if tid and tid != ElementId.InvalidElementId: return source_doc.GetElement(tid)
    except: pass
    return None


def get_level(el, source_doc):
    try:
        lid = el.LevelId
        if lid and lid != ElementId.InvalidElementId:
            lev = source_doc.GetElement(lid)
            if lev: return name(lev), eid(lid)
    except: pass
    for bip in (BuiltInParameter.LEVEL_PARAM, BuiltInParameter.INSTANCE_REFERENCE_LEVEL_PARAM):
        try:
            p = el.get_Parameter(bip)
            if p:
                lev = source_doc.GetElement(p.AsElementId())
                if lev: return name(lev), eid(lev.Id)
        except: pass
    return '', ''


def bbox(el):
    try:
        b = el.get_BoundingBox(None)
        if not b: return {}
        dx,dy,dz = abs(b.Max.X-b.Min.X), abs(b.Max.Y-b.Min.Y), abs(b.Max.Z-b.Min.Z)
        return {'BBox Min X (ft)':b.Min.X,'BBox Min Y (ft)':b.Min.Y,'BBox Min Z (ft)':b.Min.Z,
                'BBox Max X (ft)':b.Max.X,'BBox Max Y (ft)':b.Max.Y,'BBox Max Z (ft)':b.Max.Z,
                'BBox Width (ft)':dx,'BBox Depth (ft)':dy,'BBox Height (ft)':dz,
                'BBox Width (m)':dx*0.3048,'BBox Depth (m)':dy*0.3048,'BBox Height (m)':dz*0.3048}
    except: return {}


def location_data(el):
    try:
        loc=el.Location
        if loc:
            try:
                p=loc.Point
                return {'Location Type':'Point','Location X (ft)':p.X,'Location Y (ft)':p.Y,'Location Z (ft)':p.Z}
            except:
                try:
                    c=loc.Curve; a=c.GetEndPoint(0); b=c.GetEndPoint(1)
                    return {'Location Type':'Curve','Start X (ft)':a.X,'Start Y (ft)':a.Y,'Start Z (ft)':a.Z,
                            'End X (ft)':b.X,'End Y (ft)':b.Y,'End Z (ft)':b.Z}
                except: pass
    except: pass
    return {}


def geometry_summary(el, errors, src, element_id):
    if not INCLUDE_GEOMETRY_SUMMARY: return {}
    try:
        opt=Options(); opt.ComputeReferences=False; opt.IncludeNonVisibleObjects=False
        geom=el.get_Geometry(opt)
        solids=faces=0; volume=0.0
        if geom:
            for obj in geom:
                if isinstance(obj,Solid) and obj.Volume>0:
                    solids+=1; volume+=obj.Volume; faces+=obj.Faces.Size
                elif isinstance(obj,GeometryInstance):
                    try:
                        for sub in obj.GetInstanceGeometry():
                            if isinstance(sub,Solid) and sub.Volume>0:
                                solids+=1; volume+=sub.Volume; faces+=sub.Faces.Size
                    except: pass
        return {'Geometry Solid Count':solids,'Geometry Face Count':faces,'Geometry Volume (ft³)':volume}
    except Exception as ex:
        errors.append({'Source Document':src,'Element ID':element_id,'Stage':'Geometry','Error':str(ex)})
        return {}


def collect_materials(el, source_doc, src, element_id, cat, errors):
    out=[]
    if not INCLUDE_MATERIALS: return out
    try:
        for mid in el.GetMaterialIds(False):
            try:
                mat=source_doc.GetElement(mid)
                if not mat: continue
                r={'Source Document':src,'Element ID':element_id,'Category':cat,'Material ID':eid(mid),
                   'Material Name':name(mat),'Material Class':safe(lambda:mat.MaterialClass,'')}
                try: r['Material Area (ft²)']=el.GetMaterialArea(mid,False)
                except: r['Material Area (ft²)']=''
                try: r['Material Volume (ft³)']=el.GetMaterialVolume(mid)
                except: r['Material Volume (ft³)']=''
                r['Material Color']=safe(lambda:'RGB({},{},{})'.format(mat.Color.Red,mat.Color.Green,mat.Color.Blue),'')
                out.append(r)
            except Exception as ex: errors.append({'Source Document':src,'Element ID':element_id,'Stage':'Material item','Error':str(ex)})
    except Exception as ex: errors.append({'Source Document':src,'Element ID':element_id,'Stage':'Material collection','Error':str(ex)})
    return out


def collect_parameters(el, source_doc, src, element_id, kind, cat, rows, errors):
    try:
        for p in el.Parameters:
            try:
                d=p.Definition; pname=d.Name if d else ''
                guid=safe(lambda:p.GUID.ToString() if p.IsShared else '', '')
                rows.append({'Source Document':src,'Element ID':element_id,'Kind':kind,'Category':cat,
                    'Parameter Name':pname,'Value':param_value(p),'Formatted Value':safe(lambda:p.AsValueString(),''),
                    'Storage Type':safe(lambda:str(p.StorageType),''),'Parameter ID':safe(lambda:eid(p.Id),''),
                    'Shared GUID':guid,'Read Only':safe(lambda:bool(p.IsReadOnly),'')})
            except Exception as ex: errors.append({'Source Document':src,'Element ID':element_id,'Stage':'Parameter item','Error':str(ex)})
    except Exception as ex: errors.append({'Source Document':src,'Element ID':element_id,'Stage':'Parameter collection','Error':str(ex)})


def process(el, source_doc, src, kind, master, params, materials, audit, errors):
    element_id=eid(el.Id); cat=category(el)
    try:
        te=el if kind=='TYPE' else get_type(el,source_doc)
        level, level_id=get_level(el,source_doc)
        family=safe(lambda:te.FamilyName,'') if te else ''
        if not family and te: family=safe(lambda:te.Family.Name,'')
        host=safe(lambda:el.Host,None)
        row={'Source Document':src,'Element ID':element_id,'Unique ID':safe(lambda:el.UniqueId,''),'Kind':kind,
             'Category':cat,'Category ID':safe(lambda:eid(el.Category.Id) if el.Category else '', ''),
             'Element Name':name(el),'Family':family,'Type Name':name(te) if te else '',
             'Type ID':safe(lambda:eid(el.GetTypeId()),''),'API Class':safe(lambda:el.GetType().Name,''),
             'Level':level,'Level ID':level_id,'Host ID':eid(host.Id) if host else '', 'Host Name':name(host) if host else ''}
        for pname in ('Description','Mark','Comments','Type Mark','Assembly Code','Keynote','Manufacturer','Model','Cost','Length','Area','Volume','Width','Height','Thickness','Count'):
            try:
                p=el.LookupParameter(pname)
                if p: row[pname]=param_value(p)
            except: pass
        row.update(location_data(el)); row.update(bbox(el)); row.update(geometry_summary(el,errors,src,element_id))
        master.append(row)
        collect_parameters(el,source_doc,src,element_id,kind,cat,params,errors)
        materials.extend(collect_materials(el,source_doc,src,element_id,cat,errors))
        audit.append({'Source Document':src,'Element ID':element_id,'Kind':kind,'Category':cat,'Status':'OK'})
    except Exception as ex:
        errors.append({'Source Document':src,'Element ID':element_id,'Stage':'Element processing','Error':str(ex)})
        audit.append({'Source Document':src,'Element ID':element_id,'Kind':kind,'Category':cat,'Status':'FAILED','Error':str(ex)})


def export_doc(source_doc, src, master, params, materials, audit, errors, type_rows):
    try:
        for el in FilteredElementCollector(source_doc).WhereElementIsNotElementType().ToElements():
            process(el,source_doc,src,'INSTANCE',master,params,materials,audit,errors)
    except Exception as ex: errors.append({'Source Document':src,'Stage':'Instance collector','Error':str(ex)})
    if INCLUDE_TYPES:
        try:
            for el in FilteredElementCollector(source_doc).WhereElementIsElementType().ToElements():
                process(el,source_doc,src,'TYPE',master,params,materials,audit,errors)
                type_rows.append({'Source Document':src,'Element ID':eid(el.Id),'Category':category(el),
                    'Type Name':name(el),'API Class':safe(lambda:el.GetType().Name,''),'Unique ID':safe(lambda:el.UniqueId,'')})
        except Exception as ex: errors.append({'Source Document':src,'Stage':'Type collector','Error':str(ex)})


def excel_value(v):
    if isinstance(v,(dict,list,tuple)): return json.dumps(v,ensure_ascii=False,default=str)
    if v is None: return ''
    s=safe(lambda:len(str(v)),'')
    return str(v)[:32000] if isinstance(s,int) and s>32000 else v


def write_excel(path, datasets):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter
    wb=Workbook(); used=set()
    def sheet(name, rows):
        sh=wb.create_sheet(name[:31]); used.add(sh.title)
        if not rows: sh.append(['No records']); return sh
        cols=[]
        for r in rows:
            for k in r:
                if k not in cols: cols.append(k)
        sh.append(cols)
        for r in rows: sh.append([excel_value(r.get(c,'')) for c in cols])
        return sh
    sh=wb.active; sh.title='ALL ELEMENTS'; used.add(sh.title)
    rows=datasets['master']
    if rows:
        cols=[]
        for r in rows:
            for k in r:
                if k not in cols: cols.append(k)
        sh.append(cols)
        for r in rows: sh.append([excel_value(r.get(c,'')) for c in cols])
    else: sh.append(['No records'])
    sheet('ALL PARAMETERS',datasets['params']); sheet('ALL MATERIALS',datasets['materials']); sheet('ELEMENT TYPES',datasets['types']); sheet('ELEMENT AUDIT',datasets['audit']); sheet('ERRORS',datasets['errors'])
    cats=defaultdict(list)
    for r in rows: cats[r.get('Category') or 'UNCATEGORIZED'].append(r)
    for cat,catrows in sorted(cats.items()):
        title=('CAT '+str(cat))[:31]
        if title in used: title=(title[:26]+'_'+str(len(used)))[:31]
        sheet(title,catrows)
    counts=defaultdict(lambda:{'Instances':0,'Types':0,'Total':0})
    for r in rows:
        c=r.get('Category') or 'UNCATEGORIZED'; counts[c]['Total']+=1; counts[c]['Instances' if r.get('Kind')=='INSTANCE' else 'Types']+=1
    sheet('CATEGORY SUMMARY',[{'Category':c,**v} for c,v in sorted(counts.items())])
    for ws in wb.worksheets:
        ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions
        for cell in ws[1]:
            cell.font=Font(bold=True,color='FFFFFF'); cell.fill=PatternFill('solid',fgColor='244062'); cell.alignment=Alignment(wrap_text=True,vertical='center')
        ws.row_dimensions[1].height=28
        for col in ws.columns:
            try:
                width=max(12,min(45,max(len(str(c.value or '')) for c in col[:150])+2))
                ws.column_dimensions[get_column_letter(col[0].column)].width=width
            except: pass
    wb.save(path)


try:
    folder=forms.pick_folder(title='Select folder for Universal Inventory Excel export')
    if not folder: script.exit()
    master=[]; params=[]; materials=[]; audit=[]; errors=[]; types=[]
    export_doc(DOC,'Active Document',master,params,materials,audit,errors,types)
    filename='Revit_Universal_Inventory_{}.xlsx'.format(safe(lambda:DOC.Title,'Model').replace(' ','_'))
    path=os.path.join(folder,filename)
    write_excel(path,{'master':master,'params':params,'materials':materials,'audit':audit,'errors':errors,'types':types})
    forms.alert('Export completed.\n\nElements and types recorded: {}\nParameter rows: {}\nMaterial rows: {}\nAudit failures: {}\n\nFile:\n{}'.format(len(master),len(params),len(materials),len([x for x in audit if x.get('Status')=='FAILED']),path),title='Universal Inventory',ok=True)
except Exception as ex:
    forms.alert('Export failed:\n{}\n\n{}'.format(str(ex),traceback.format_exc()),title='Universal Inventory Error',ok=True)
