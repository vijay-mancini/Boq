# Frontend placeholder

Planned UI: project overview, extraction status, classification review queue, quantity rules, BOQ items, element traceability, validation warnings and exports. Phase 1 uses pyRevit's folder selection and completion dialogs only.
