# -*- coding: utf-8 -*-
"""BIM-BOQ MVP: Revit model snapshot extractor. IronPython 2.7 / pyRevit."""
from Autodesk.Revit.DB import *
from pyrevit import revit, forms, script
import os, csv, traceback

DOC = revit.doc
OUT = script.get_output()

# Revit internal units: feet, square feet, cubic feet. Convert explicitly.
FT_TO_M = 0.3048
FT2_TO_M2 = 0.09290304
FT3_TO_M3 = 0.028316846592


def txt(value):
    try:
        if value is None: return u""
        return unicode(value)
    except:
        try: return str(value)
        except: return u"<unreadable>"


def safe_name(el):
    try: return txt(el.Name)
    except: return u""


def category_name(el):
    try: return txt(el.Category.Name)
    except: return u""


def element_id(el):
    try: return str(el.Id.IntegerValue)
    except: return ""


def type_id(el):
    try: return str(el.GetTypeId().IntegerValue)
    except: return ""


def type_element(el):
    try:
        tid = el.GetTypeId()
        if tid and tid != ElementId.InvalidElementId:
            return DOC.GetElement(tid)
    except: pass
    return None


def level_name(el):
    # Try common level-related parameters and then element Level property.
    for pname in ["Level", "Schedule Level", "Reference Level", "Base Level"]:
        try:
            p = el.LookupParameter(pname)
            if p and p.AsElementId() and p.AsElementId() != ElementId.InvalidElementId:
                lev = DOC.GetElement(p.AsElementId())
                if lev: return txt(lev.Name)
        except: pass
    try:
        lev = el.Level
        if lev: return txt(lev.Name)
    except: pass
    return u""


def param_value(p):
    try:
        if p.StorageType == StorageType.String: return txt(p.AsString())
        if p.StorageType == StorageType.Integer: return txt(p.AsInteger())
        if p.StorageType == StorageType.ElementId:
            eid = p.AsElementId()
            if eid and eid != ElementId.InvalidElementId:
                obj = DOC.GetElement(eid)
                return txt(obj.Name) if obj else txt(eid.IntegerValue)
            return ""
        if p.StorageType == StorageType.Double:
            # Store raw internal value plus formatted value; unit interpretation varies by parameter.
            return txt(p.AsValueString()) if p.AsValueString() else txt(p.AsDouble())
    except: pass
    try: return txt(p.AsValueString())
    except: return ""


def get_parameter_rows(el):
    rows = []
    try:
        for p in el.Parameters:
            try:
                pname = txt(p.Definition.Name)
                rows.append([element_id(el), pname, txt(p.StorageType), param_value(p), txt(p.AsValueString()), str(p.IsShared)])
            except: continue
    except: pass
    return rows


def material_rows(el, include_paint):
    rows = []
    try:
        ids = el.GetMaterialIds(include_paint)
    except: ids = []
    for mid in ids:
        try:
            mat = DOC.GetElement(mid)
            if not mat: continue
            try: vol = el.GetMaterialVolume(mid) * FT3_TO_M3
            except: vol = 0.0
            try: area = el.GetMaterialArea(mid, include_paint) * FT2_TO_M2
            except: area = 0.0
            rows.append([element_id(el), category_name(el), safe_name(el), txt(mid.IntegerValue), txt(mat.Name), "Paint" if include_paint else "NonPaint", area, vol])
        except: continue
    return rows


def geometry_metrics(el):
    # Approximate totals of measurable solids only; not a BOQ rule or formwork quantity.
    total_vol = 0.0
    total_surface = 0.0
    solid_count = 0
    try:
        opt = Options()
        opt.ComputeReferences = False
        opt.IncludeNonVisibleObjects = False
        geom = el.get_Geometry(opt)
        stack = list(geom) if geom else []
        while stack:
            obj = stack.pop()
            if isinstance(obj, Solid):
                try:
                    if obj.Volume > 1e-9:
                        total_vol += obj.Volume
                        total_surface += obj.SurfaceArea
                        solid_count += 1
                except: pass
            elif isinstance(obj, GeometryInstance):
                try:
                    inst = obj.GetInstanceGeometry()
                    if inst: stack.extend(list(inst))
                except: pass
    except: pass
    return [solid_count, total_vol * FT3_TO_M3, total_surface * FT2_TO_M2]


def write_csv(path, headers, rows):
    # IronPython csv expects byte strings; encode Unicode as UTF-8.
    with open(path, 'wb') as f:
        w = csv.writer(f)
        w.writerow([txt(h).encode('utf-8') for h in headers])
        for row in rows:
            w.writerow([txt(x).encode('utf-8') if isinstance(x, unicode) else x for x in row])


folder = forms.select_folder(title="Choose folder for BIM-BOQ model snapshot")
if not folder:
    script.exit()

# Warn that the snapshot contains broad model data and may be large.
forms.alert("Extraction will scan all non-type elements in the active project.\n\nThis may take time on large models.", title="BIM-BOQ Extractor", ok=True)

all_elements = FilteredElementCollector(DOC).WhereElementIsNotElementType().ToElements()
element_rows = []
material_rows_out = []
parameter_rows = []
geometry_rows = []
error_rows = []

for el in all_elements:
    try:
        eid = element_id(el)
        typ = type_element(el)
        fam = ""
        try: fam = txt(typ.FamilyName)
        except:
            try: fam = txt(typ.Family.Name)
            except: pass
        tname = safe_name(typ) if typ else ""
        row = [eid, category_name(el), safe_name(el), fam, tname, type_id(el), level_name(el), txt(el.UniqueId)]
        element_rows.append(row)
        parameter_rows.extend(get_parameter_rows(el))
        material_rows_out.extend(material_rows(el, False))
        material_rows_out.extend(material_rows(el, True))
        geom = geometry_metrics(el)
        geometry_rows.append([eid, category_name(el), safe_name(el), geom[0], geom[1], geom[2]])
    except Exception as ex:
        error_rows.append([element_id(el), category_name(el), safe_name(el), txt(ex), txt(traceback.format_exc())])

try:
    write_csv(os.path.join(folder, "Elements.csv"), ["ElementId","Category","ElementName","FamilyName","TypeName","TypeId","Level","UniqueId"], element_rows)
    write_csv(os.path.join(folder, "Materials.csv"), ["ElementId","Category","ElementName","MaterialId","MaterialName","AssignmentKind","MaterialArea_m2","MaterialVolume_m3"], material_rows_out)
    write_csv(os.path.join(folder, "Parameters.csv"), ["ElementId","ParameterName","StorageType","Value","FormattedValue","IsShared"], parameter_rows)
    write_csv(os.path.join(folder, "Geometry.csv"), ["ElementId","Category","ElementName","SolidCount","SolidVolume_m3","SolidSurfaceArea_m2"], geometry_rows)
    write_csv(os.path.join(folder, "Errors.csv"), ["ElementId","Category","ElementName","Error","Traceback"], error_rows)
    forms.alert("Snapshot complete.\n\nElements: {}\nMaterial rows: {}\nParameter rows: {}\nGeometry records: {}\nErrors: {}\n\nFiles saved to:\n{}".format(len(element_rows), len(material_rows_out), len(parameter_rows), len(geometry_rows), len(error_rows), folder), title="BIM-BOQ Extractor")
except Exception as ex:
    forms.alert("Export failed:\n{}\n\n{}".format(txt(ex), txt(traceback.format_exc())), title="BIM-BOQ Extractor Error")
