import csv, tempfile, unittest, sqlite3, os
from pathlib import Path
from backend.engine import import_snapshot, calculate, export_excel
from backend.classification import classify_category

ROOT=Path(__file__).resolve().parents[1]
RULES=ROOT/'rules'/'measurement_rules.json'
class EngineTests(unittest.TestCase):
 def test_snapshot_import_calculation_export(self):
  with tempfile.TemporaryDirectory() as td:
   d=Path(td); db=d/'test.sqlite'; out=d/'out.xlsx'
   def write(name,headers,rows):
    with (d/name).open('w',newline='',encoding='utf-8') as f:
     w=csv.writer(f); w.writerow(headers); w.writerows(rows)
   write('Elements.csv',['ElementId','Category','ElementName','FamilyName','TypeName','TypeId','Level','UniqueId'],[['1','Walls','W-1','Basic Wall','200mm','9','L1','uid1']])
   write('Materials.csv',['ElementId','Category','ElementName','MaterialId','MaterialName','AssignmentKind','MaterialArea_m2','MaterialVolume_m3'],[['1','Walls','W-1','3','PCC','NonPaint','10','2'],['1','Walls','W-1','3','PCC','Paint','10','2']])
   write('Parameters.csv',['ElementId','ParameterName','StorageType','Value','FormattedValue','IsShared'],[['1','Length','Double','4','4 m','False']])
   write('Geometry.csv',['ElementId','Category','ElementName','SolidCount','SolidVolume_m3','SolidSurfaceArea_m2'],[['1','Walls','W-1','1','3.5','12']])
   write('Errors.csv',['ElementId','Category','ElementName','Error','Traceback'],[['2','Walls','bad','test error','trace']])
   result=import_snapshot(d,db,'fixture')
   self.assertEqual(result,(1,1,2,1,1,1))
   rows=calculate(1,db,RULES)
   # Existing active rules intentionally match material names and quantity both passes currently.
   self.assertTrue(rows)
   count=export_excel(1,db,out); self.assertTrue(out.exists()); self.assertGreater(count,0)
   conn=sqlite3.connect(db); self.assertEqual(conn.execute('select count(*) from geometry').fetchone()[0],1); self.assertEqual(conn.execute('select count(*) from errors').fetchone()[0],1); conn.close()
if __name__=='__main__': unittest.main()
