# BIM BOQ Automation — MVP development package

Current components: pyRevit CSV extractor starter; SQLite import/normalization; rule-driven quantity aggregation; traceable BOQ Excel export; minimal API.

**Important:** not production-ready or verified against a Revit model. Provisional rules are not construction-certified. Formwork/contact-face measurement, deductions, comprehensive classification, UI and database revision/change handling remain unfinished.

See `docs/ROADMAP.md`, `docs/PROGRESS.md`, `backend/README.md`.

## v0.4 additions
- Rule-based architectural element classification report (`CLASSIFICATION.csv`) via `backend/classification.py`.
- Expanded rule filtering: category, name include/exclude, material name and level.
- Classification is heuristic and must be reviewed against project standards.
