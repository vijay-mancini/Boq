"""Rule-based Revit element classification helper (heuristic, editable)."""
import csv, json
from pathlib import Path

DEFAULT_MAP = {
 "Walls": "Wall", "Floors": "Floor", "Ceilings": "Ceiling", "Doors": "Door",
 "Windows": "Window", "Roofs": "Roof", "Columns": "Column", "Structural Columns": "Column",
 "Structural Framing": "Beam", "Stairs": "Stair", "Ramps": "Ramp", "Railings": "Railing",
 "Furniture": "Furniture", "Casework": "Casework", "Curtain Wall Panels": "Curtain panel",
 "Curtain Wall Mullions": "Mullion", "Generic Models": "Generic model", "Rooms": "Room"
}

def classify_category(category, mapping=None):
    mapping = mapping or DEFAULT_MAP
    return mapping.get(category, "Unclassified")

def classify_snapshot(folder, output_path=None, mapping=None):
    folder=Path(folder); output_path=Path(output_path or folder/'CLASSIFICATION.csv')
    src=folder/'ELEMENTS.csv'
    if not src.exists(): src=folder/'Elements.csv'
    if not src.exists(): raise FileNotFoundError('ELEMENTS.csv not found in snapshot')
    with src.open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
    mapping=mapping or DEFAULT_MAP
    results=[]
    for r in rows:
        cat=r.get('Category','')
        results.append({"ElementId":r.get('ElementId',''),"Category":cat,"Class":classify_category(cat,mapping),
          "Name":r.get('ElementName',r.get('Name','')),"Family":r.get('FamilyName',r.get('Family','')),
          "Type":r.get('TypeName',r.get('Type','')),"Level":r.get('Level','')})
    with output_path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(results[0]) if results else ["ElementId","Category","Class","Name","Family","Type","Level"])
        w.writeheader(); w.writerows(results)
    counts={}
    for r in results: counts[r['Class']]=counts.get(r['Class'],0)+1
    return results,counts
