import argparse, os
from engine import import_snapshot, calculate, export_excel

def main():
 p=argparse.ArgumentParser(description='BIM BOQ rule engine'); sub=p.add_subparsers(dest='cmd',required=True)
 i=sub.add_parser('import'); i.add_argument('folder'); i.add_argument('--db',default='bimboq.sqlite'); i.add_argument('--name')
 c=sub.add_parser('calculate'); c.add_argument('--project',type=int,required=True); c.add_argument('--db',default='bimboq.sqlite'); c.add_argument('--rules',default='../rules/measurement_rules.json')
 e=sub.add_parser('export'); e.add_argument('--project',type=int,required=True); e.add_argument('--db',default='bimboq.sqlite'); e.add_argument('--output',default='BOQ.xlsx')
 a=p.parse_args()
 if a.cmd=='import': print('Imported project:',import_snapshot(a.folder,a.db,a.name))
 elif a.cmd=='calculate': print('BOQ rows:',len(calculate(a.project,a.db,a.rules)))
 else: print('Exported rows:',export_excel(a.project,a.db,a.output),'to',a.output)
if __name__=='__main__': main()
