from fastapi import FastAPI, HTTPException
import sqlite3, os
app=FastAPI(title='BIM BOQ API',version='0.1.0')
DB=os.environ.get('BIMBOQ_DB','bimboq.sqlite')
@app.get('/health')
def health(): return {'status':'ok','database':DB}
@app.get('/projects')
def projects():
 if not os.path.exists(DB): return []
 db=sqlite3.connect(DB); rows=db.execute('SELECT id,name,source_dir,imported_at FROM projects ORDER BY id DESC').fetchall(); db.close(); return [{'id':r[0],'name':r[1],'source_dir':r[2],'imported_at':r[3]} for r in rows]
@app.get('/projects/{project_id}/boq')
def boq(project_id:int):
 if not os.path.exists(DB): raise HTTPException(404,'Database not found')
 db=sqlite3.connect(DB); db.row_factory=sqlite3.Row; rows=db.execute('SELECT * FROM boq WHERE project_id=?',(project_id,)).fetchall(); db.close(); return [dict(r) for r in rows]
