# Roadmap

## Phase 1 — Snapshot extraction (included MVP)
- Elements, parameters, materials, basic geometry diagnostics, failures.

## Phase 2 — Data normalization
- Stable database schema, parameter normalization, category/type dictionary, linked model support, extraction profiles, change detection.

## Phase 3 — Measurement engine
- Rule-driven gross/net volume and area, length/count, compound layer measurement, openings, exclusions, contact-surface/formwork calculations with explicit assumptions.

## Phase 4 — Classification engine
- Construction work package mapping based on category, family/type, materials, parameters, assemblies, and user rules. Uncertain mappings remain in review queue.

## Phase 5 — BOQ generation
- BOQ sections, item descriptions, units, aggregation keys, traceability, rate/amount columns, Excel templates.

## Phase 6 — Audit and reconciliation
- Element-to-item trace, duplicate detection, uncovered elements, quantity discrepancies, geometry warnings, confidence/review statuses.

## Phase 7 — UI and persistence
- Project dashboard, rule editor, SQLite database, revision history, exports, user overrides.

## Phase 8 — Production deployment
- Revit version support matrix, installer, logging, testing, backups, update process.
