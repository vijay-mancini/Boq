# Progress ledger — v0.4

## Increment
- Added a rule-based architectural classification helper that writes CLASSIFICATION.csv from element snapshots.
- Refined measurement-rule matching with category, name include/exclude, material-name and level filters.
- Added a parameter value helper for case-insensitive parameter-based rules.
- Added classification test assertion to the existing end-to-end fixture test.

## Validation
- Synthetic fixture test and Python syntax compilation are run as part of this increment.
- This is not live Revit validation. Heuristic classification is editable and unknown categories remain Unclassified.
