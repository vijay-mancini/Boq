# -*- coding: utf-8 -*-
"""pyRevit button entry point for combined material BOQ export."""

import os
import re
import sys

from pyrevit import forms

# Ensure the helper module in this pushbutton folder is importable in both
# IronPython and CPython-based pyRevit engines.
_bundle_dir = os.path.dirname(__file__)
if _bundle_dir not in sys.path:
    sys.path.insert(0, _bundle_dir)

import boq_exporter


def main():
    uidoc = __revit__.ActiveUIDocument
    if uidoc is None:
        forms.alert(u"No active Revit document is open.", title=u"Material BOQ Export")
        return

    doc = uidoc.Document
    if doc is None:
        forms.alert(u"No Revit document is currently open.", title=u"Material BOQ Export")
        return

    forms.alert(
        u"This export creates one combined Excel sheet.\n\n"
        u"COMPOUND STRUCTURE: one row per layer of each individual Wall, Floor, "
        u"Roof or Ceiling instance.\n\n"
        u"NON-COMPOUND: other physical model elements (such as doors, windows, "
        u"columns, beams, furniture and generic models) are included one row per "
        u"element/material.\n\n"
        u"The Structure Type column labels each row as Compound Structure or "
        u"Non-Compound. Elements are not grouped together.",
        title=u"Material BOQ Export",
    )

    try:
        data = boq_exporter.collect_export_data(doc)
    except Exception as collect_error:
        forms.alert(
            u"Model data collection failed.\n\n{0}".format(boq_exporter.as_text(collect_error)),
            title=u"Material BOQ Export - Error",
        )
        raise

    if not data["rows"]:
        forms.alert(
            u"No compound-layer elements or physical non-compound elements with "
            u"solid geometry/material data were found in this model.",
            title=u"Material BOQ Export",
        )
        return

    model_title = boq_exporter.as_text(doc.Title)
    safe_title = re.sub(
        r"[^A-Za-z0-9_.-]+", "_", model_title
    ).strip("_.") or "Revit_Model"
    default_name = u"{0}_Material_BOQ_All_Elements.xlsx".format(safe_title)

    output_path = forms.save_file(
        file_ext=u"xlsx",
        default_name=default_name,
        title=u"Save Combined Material BOQ Excel File",
    )
    if not output_path:
        return
    if not output_path.lower().endswith(u".xlsx"):
        output_path += u".xlsx"

    headers = [
        u"Structure Type",
        u"Category",
        u"Name",
        u"Element ID",
        u"Material Type",
        u"Material ID",
        u"Layer Order",
        u"Thickness (m)",
        u"Length (m)",
        u"Height / Width (m)",
        u"Area (m²)",
        u"Volume (m³)",
    ]

    try:
        boq_exporter.write_xlsx(output_path, [headers] + data["rows"])
    except Exception as export_error:
        forms.alert(
            u"Excel export failed.\n\n{0}".format(boq_exporter.as_text(export_error)),
            title=u"Material BOQ Export - Error",
        )
        raise

    forms.alert(
        u"Excel export completed.\n\n"
        u"File: {0}\n\n"
        u"Compound structure elements: {1}\n"
        u"Compound layer rows: {2}\n"
        u"Non-compound elements: {3}\n"
        u"Non-compound material rows: {4}\n"
        u"Other model instances inspected: {5}\n"
        u"Other instances skipped (no solid/material data): {6}\n\n"
        u"All data is written to the same 'Material BOQ' worksheet.\n"
        u"Each element instance remains separate.".format(
            output_path,
            data["compound_elements"],
            len(data["compound_rows"]),
            data["noncompound_elements"],
            len(data["noncompound_rows"]),
            data["other_instances_scanned"],
            data["other_instances_skipped"],
        ),
        title=u"Material BOQ Export",
    )


main()
