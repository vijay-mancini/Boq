MATERIAL BOQ - ALL ELEMENTS (pyRevit)

PACKAGE CONTENTS
- script.py: pyRevit pushbutton entry point and Excel export workflow.
- boq_exporter.py: separate helper module containing Revit data extraction and XLSX writer.

INSTALLATION
1. Copy the complete folder "Material_BOQ_All_Elements.pushbutton" into your
   pyRevit extension panel folder (for example, inside your BOQ.panel folder).
2. Keep both script.py and boq_exporter.py in this same pushbutton folder.
3. Reload pyRevit in Revit.
4. Click the new "Material BOQ - All Elements" pushbutton.
5. Choose the output Excel file path.

EXCEL OUTPUT
The workbook contains one worksheet named "Material BOQ" with these columns:
1. Structure Type
2. Category
3. Name
4. Element ID
5. Material Type
6. Material ID
7. Layer Order
8. Thickness (m)
9. Length (m)
10. Height / Width (m)
11. Area (m2)
12. Volume (m3)

HOW ELEMENTS ARE CLASSIFIED
- Compound Structure: standard compound-structure layers from Wall, Floor, Roof
  and Ceiling system-family instances. One row is exported for each layer of
  each individual element instance.
- Non-Compound: other physical model instances and any Wall/Floor/Roof/Ceiling
  instances that do not expose a standard compound structure. One row is
  exported per individual element and assigned material. If a solid element
  has no material assigned, it is still included with "<No Material Assigned>".
- Every row includes an Element ID. Elements are not grouped by type, material,
  or category.

QUANTITY AND DIMENSION RULES
- Revit internal lengths are converted to metres, areas to square metres and
  volumes to cubic metres.
- Compound rows: Thickness comes from the compound layer. Area uses the Revit
  host area parameter when available, then geometry-based fallback. Volume is
  estimated per layer as Area x layer Thickness.
- Non-compound rows: Thickness and Layer Order are blank because these elements
  do not expose compound layers. Material-specific area and volume are read
  from the Revit API when available. If a material-specific quantity is not
  available, whole-element area/volume is used only when there is a single
  material row, avoiding duplication across multiple materials.
- Wall Length uses the location curve when available; wall height uses the
  solid geometry Z extent. Floors/Roofs/Ceilings use the longer and shorter
  horizontal geometry envelope dimensions. Other elements use location curve
  length when available, otherwise the longer horizontal geometry dimension;
  their Height/Width value is the geometry Z extent.
- Geometry envelope dimensions are not necessarily exact physical edge
  lengths for rotated, sloped or irregular elements.

IMPORTANT LIMITATIONS
- Non-compound elements are included only when Revit reports assigned material
  IDs or the element has solid geometry. Annotation-only objects (grids,
  dimensions, levels, view graphics, etc.) are intentionally skipped.
- Material assignment and quantity availability depend on how each family,
  in-place element or system family was authored in Revit.
- A non-compound element with multiple materials may have blank area/volume if
  Revit does not provide material-specific quantities. The script does not
  duplicate the whole-element quantity for each material.
- Review output against project measurement rules before using it as a certified
  BOQ. The script reads model data only and does not modify the Revit model.
